'''
        Copyright 2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
        SPDX-License-Identifier: MIT-0
'''
import json
import boto3
import time
import logging
import requests
s3Client = boto3.client('s3')
dynamodb = boto3.client('dynamodb')
rekognition = boto3.client('rekognition')
face_collection = "Faces" # Name of the face collection that the AWS Rekognition uses
face_match_threshold = 70 # Match Threshold for the faces to be concidered the same person
logging_table = 'logs' # DynamoDB table name for the log files
#DynamoDB
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError
dynamodb = boto3.resource("dynamodb", region_name = '')
dynamodbTables = boto3.client('dynamodb')
TableFaces = dynamodb.Table('Faces') #DynamoDB table created
collectionId = 'Faces' #Name of your face collection
bucket = '' #bucket name
slack_token = "" #slack bot token
slack_channel = "" #ID do channel do slack
def lambda_handler(event, context):
    utime = str(int(time.time())) #Current Unix Time   
    handle_event(event, context)
def handle_event(evt, ctx):
    key = evt['Records'][0]['s3']['object']['key']  
    S3Object = { #create an S3 object
        "S3Object": {
            "Bucket": bucket,
            "Name": key,
        }
    }
    try:
        checkForExistingTable = dynamodbTables.describe_table(TableName='Faces')
    except dynamodbTables.exceptions.ResourceNotFoundException:
        newTable()
        raise e
    #Will check if the collection exists
    collectionList = rekognition.list_collections(MaxResults=10)
    for collection in collectionList['CollectionIds']:
        if collection == collectionId:
            break
    if collection == collectionId:
        print(collection)
        #This will 'scan' the curret image searching faces
        #method rekognition.search_faces_by_image(NameOfTheCollection, S3Object, Threshold, MaxFacesInTheImage)
        searchFaces = rekognition.search_faces_by_image(CollectionId=collectionId, Image=S3Object, FaceMatchThreshold=70, MaxFaces=2)
        if len(searchFaces['FaceMatches']) != 0 : #this means that searchFaces find a face in the photo
            print(searchFaces['FaceMatches'])
            #Search on the DynammoDB Table a item that correspond with the item searchFaces['FaceMatches'][0]['Face']['FaceId']
            consultDynamo = TableFaces.query(KeyConditionExpression=Key('faceID').eq(searchFaces['FaceMatches'][0]['Face']['FaceId']))
            if len(consultDynamo['Items']) != 0: #This means that the item existis in the the Table
                #Will run the function passing some values, including the Id of the user
                slackNotifications('', consultDynamo['Items'][0]['SlackID'], key)
            else:
                slackNotifications('user not found', consultDynamo['Items'][0]['SlackID'], key)
        else:
            #if dont recognize any face, then the image will be used to train an new faceId in the collection
            addFacesToCollection(key, S3Object)
    else:
        createCollection()
def createCollection():
    newCollection = rekognition.create_collection(CollectionId=collectionId)
    slackNotifications('NewCollection', collectionId, key)
def addFacesToCollection(key, image):
    print(key)
    print(image)
    #With this function a new faceId will be trained in the collection.
    #The message that will be showed in the slack is the Id of the face, 
    #so, you can change the SlackId created by the current user id of the user
    newFace = rekognition.index_faces(CollectionId=collectionId, Image=image, MaxFaces=2)
    print(newFace)
    newTableItem = TableFaces.put_item(Item={'faceID':newFace['FaceRecords'][0]['Face']['FaceId'], 'SlackID':'newUser'})
    print(newTableItem)
    return slackNotifications("New User", newFace['FaceRecords'][0]['Face']['FaceId'], image)
def slackNotifications(message, userID, key):
    '''
        Will notify in a channel of the slack
    '''
    text = ''
    data = {
        'token': slack_token,
        'user': userID
    }
    slackJson = {
        'channel': slack_channel,
        'text': text,
        'icon_emoji': ':robot_face:',
    }
    if message == "New User":
        slackJson['text'] = 'The user with the faceID %s was successfully added' % userID
    elif message == "user not found":
        slackJson['text'] = 'I cant find the Slack Id of the user with Face Id %s' % userID
    elif message == "NewCollection":
        slackJson['text'] = 'Collection %s created' % userID
    else:
        slackJson['text'] = 'Hi <@%s>' % userID
    resp = requests.post("https://slack.com/api/chat.postMessage", headers={'Content-Type':'application/json;charset=UTF-8', 'Authorization': 'Bearer %s' % slack_token}, json=slackJson)
    return {}
def newTable():
    createTable = dynamodb.create_table(
        TableName='Faces',
        KeySchema=[
            {
                'AttributeName': 'faceID',
                'KeyType': 'HASH'  #Partition key
            },
            {
                'AttributeName': 'SlackID',
                'KeyType': 'RANGE'  #Sort key
            },
        ],
        AttributeDefinitions=[
            {
                'AttributeName': 'faceID',
                'AttributeType': 'S'
            },
            {
                'AttributeName': 'SlackID',
                'AttributeType': 'S'
            },
        ],
        ProvisionedThroughput={
            'ReadCapacityUnits': 30,
            'WriteCapacityUnits': 30
        }
    )
    print('Table Status:', newTable.table_sta)
    